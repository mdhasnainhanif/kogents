'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import Header from '@/components/Header'
import NewFooter from '@/components/NewFooter'
import styles from './Sitemap.module.css'

const BASE_URL = 'https://kogents.ai'

// All platform channel IDs
const platformChannels = [
  'whatsapp-ai-agent',
  'instagram-agent-ai',
  'viber-ai-agent',
  'ai-agent-for-messenger',
  'zendesk-ai-integration',
  'ai-telegram-agent',
  'microsoft-teams-agents',
  'calendly-ai-integration',
  'line-ai-agent',
  'slack-ai-agent',
  'hubspot-ai-integration',
  'jira-ai-integration'
]

// Organized page sections similar to Wix sitemap
const pageSections = {
  main: {
    title: 'Main Pages',
    icon: '🏠',
    pages: [
      { path: '/', title: 'Home', priority: 1.0, changeFrequency: 'daily' },
      { path: '/platforms', title: 'Platforms', priority: 0.9, changeFrequency: 'daily' },
      { path: '/solutions', title: 'Solutions', priority: 0.9, changeFrequency: 'daily' },
      { path: '/about-us', title: 'About Us', priority: 0.9, changeFrequency: 'daily' },
      { path: '/contact-us', title: 'Contact Us', priority: 0.9, changeFrequency: 'daily' },
      { path: '/case-studies', title: 'Case Studies', priority: 0.9, changeFrequency: 'daily' },
      { path: '/client-testimonials', title: 'Testimonials', priority: 0.9, changeFrequency: 'daily' },
      { path: '/blogs', title: 'Blogs', priority: 0.9, changeFrequency: 'daily' }
    ]
  },
  solutions: {
    title: 'AI Solutions',
    icon: '🤖',
    pages: [
      { path: '/solutions/customer-service-ai-agent', title: 'Customer Service AI Agent', priority: 0.9, changeFrequency: 'daily' },
      { path: '/solutions/ai-agent-for-marketing', title: 'AI Agent for Marketing', priority: 0.9, changeFrequency: 'daily' },
      { path: '/solutions/ai-agent-for-hr', title: 'AI Agent for HR', priority: 0.9, changeFrequency: 'daily' },
      { path: '/solutions/ai-agent-for-education', title: 'AI Agent for Education', priority: 0.9, changeFrequency: 'daily' },
      { path: '/solutions/ai-teacher-assistant', title: 'AI Teacher Assistant', priority: 0.9, changeFrequency: 'daily' },
      { path: '/solutions/healthcare-ai-agent', title: 'Healthcare AI Agent', priority: 0.9, changeFrequency: 'daily' },
      { path: '/solutions/survey-ai-agent', title: 'Survey AI Agent', priority: 0.9, changeFrequency: 'daily' },
      { path: '/solutions/ai-agent-dashboard', title: 'AI Agent Dashboard', priority: 0.9, changeFrequency: 'daily' },
      { path: '/solutions/ai-agent-event-planner', title: 'AI Agent Event Planner', priority: 0.9, changeFrequency: 'daily' }
    ]
  },
  platforms: {
    title: 'Platform Integrations',
    icon: '🔗',
    pages: platformChannels.map(channel => ({
      path: `/platforms/${channel}`,
      title: channel.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
      priority: 0.9,
      changeFrequency: 'daily'
    }))
  },
  tools: {
    title: 'Tools & Resources',
    icon: '🛠️',
    pages: [
      { path: '/chatbot/brief', title: 'Chatbot Brief', priority: 0.9, changeFrequency: 'daily' },
      { path: '/sitemap', title: 'Sitemap', priority: 0.8, changeFrequency: 'monthly' }
    ]
  },
  legal: {
    title: 'Legal & Security',
    icon: '⚖️',
    pages: [
      { path: '/privacy-statement', title: 'Privacy Statement', priority: 0.9, changeFrequency: 'daily' },
      { path: '/security', title: 'Security', priority: 0.9, changeFrequency: 'daily' },
      { path: '/terms-and-condition', title: 'Terms and Conditions', priority: 0.9, changeFrequency: 'daily' }
    ]
  }
}

export default function SitemapPage() {
  const [blogPosts, setBlogPosts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchBlogPosts() {
      try {
        const res = await fetch('/api/blog-proxy?endpoint=posts&per_page=100')
        if (res.ok) {
          const posts = await res.json()
          setBlogPosts(posts)
        }
      } catch (error) {
        console.error('Error fetching blog posts:', error)
      } finally {
        setLoading(false)
      }
    }
    fetchBlogPosts()
  }, [])

  // Calculate total pages
  const totalStaticPages = Object.values(pageSections).reduce((total, section) => total + section.pages.length, 0)
  const totalPages = totalStaticPages + blogPosts.length

  return (
    <>
      <div className={styles.sitemapContainer}>
        <div className={styles.sitemapContent}>
          <div className={styles.sitemapHeader}>
            <h1 className={styles.sitemapTitle}>Kogent AI Sitemap</h1>
            <p className={styles.sitemapSubtitle}>
              Explore all pages and resources available on our AI-powered platform. 
              Find everything from AI solutions to platform integrations and legal information.
            </p>
          </div>
          
          {/* Category Headers Row */}
          {/* <div className={`${styles.categoryHeaders} row`}>
            {Object.entries(pageSections).map(([key, section]) => (
              <div key={key} className="col-lg-2 col-md-4 col-sm-6 col-12 mb-3">
                <div className={styles.categoryHeader}>
                  <div className={styles.categoryIcon}>{section.icon}</div>
                  <div className={styles.categoryTitle}>{section.title}</div>
                </div>
              </div>
            ))}
            <div className="col-lg-2 col-md-4 col-sm-6 col-12 mb-3">
              <div className={styles.categoryHeader}>
                <div className={styles.categoryIcon}>📝</div>
                <div className={styles.categoryTitle}>Blog Posts</div>
              </div>
            </div>
          </div> */}
          
          {/* Sections with Cards */}
          {Object.entries(pageSections).map(([key, section]) => (
            <div key={key} className={styles.sectionContainer}>
              <h2 className={styles.sectionTitle}>
                <span className={styles.sectionIcon}>{section.icon}</span>
                {section.title}
              </h2>
              <div className={`${styles.cardsGrid} row`}>
                {section.pages.map((page, index) => (
                  <div key={index} className="col-lg-4 col-md-6 col-sm-12 mb-3">
                    <div className={styles.pageCard}>
                      <Link 
                        href={page.path}
                        className={styles.pageLink}
                      >
                        {page.title}
                      </Link>
                      <div className={styles.pageMeta}>
                        Priority: {page.priority} | Frequency: {page.changeFrequency}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
          
          {/* Blog Posts Section */}
          <div className={styles.sectionContainer}>
            <h2 className={styles.sectionTitle}>
              <span className={styles.sectionIcon}>📝</span>
              Blog Posts
            </h2>
            <div className={`${styles.cardsGrid} row`}>
              {loading ? (
                <div className="col-12">
                  <div className={styles.loadingContainer}>
                    <div className={styles.loadingSpinner}></div>
                    <div>Loading blog posts...</div>
                  </div>
                </div>
              ) : blogPosts.length > 0 ? (
                blogPosts.slice(0, 10).map((post, index) => (
                  <div key={index} className="col-lg-4 col-md-6 col-sm-12 mb-3">
                    <div className={styles.pageCard}>
                      <Link 
                        href={`/blogs/${post.slug}`}
                        className={styles.pageLink}
                      >
                        {post.title?.rendered || post.slug}
                      </Link>
                      <div className={styles.pageMeta}>
                        Priority: 0.6 | Frequency: weekly
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="col-12">
                  <div className={styles.pageCard}>
                    <div className={styles.pageLink}>No blog posts available</div>
                  </div>
                </div>
              )}
              {blogPosts.length > 10 && (
                <div className="col-12">
                  <div className={styles.pageCard}>
                    <Link 
                      href="/blogs"
                      className={styles.pageLink}
                      style={{ fontWeight: '600', color: '#8269FA' }}
                    >
                      View All {blogPosts.length} Blog Posts →
                    </Link>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* <div className={styles.sitemapStats}>
            <h3 className={styles.statsTitle}>Site Statistics</h3>
            <div className={`${styles.statsGrid} row`}>
              <div className="col-lg-3 col-md-6 col-sm-12 mb-3">
                <div className={styles.statItem}>
                  <span className={styles.statNumber}>{totalPages}</span>
                  <div className={styles.statLabel}>Total Pages</div>
                </div>
              </div>
              <div className="col-lg-3 col-md-6 col-sm-12 mb-3">
                <div className={styles.statItem}>
                  <span className={styles.statNumber}>{totalStaticPages}</span>
                  <div className={styles.statLabel}>Static Pages</div>
                </div>
              </div>
              <div className="col-lg-3 col-md-6 col-sm-12 mb-3">
                <div className={styles.statItem}>
                  <span className={styles.statNumber}>{blogPosts.length}</span>
                  <div className={styles.statLabel}>Blog Posts</div>
                </div>
              </div>
              <div className="col-lg-3 col-md-6 col-sm-12 mb-3">
                <div className={styles.statItem}>
                  <span className={styles.statNumber}>{Object.keys(pageSections).length}</span>
                  <div className={styles.statLabel}>Main Sections</div>
                </div>
              </div>
            </div>
          </div> */}
        </div>
      </div>
    </>
  )
}
